export type PaginationQuery = {
  page?: number
  limit?: number
}
