export type Word = {
  word: string
  added: Date
}
