export type SearchQuery = {
  page?: number
  limit?: number
  search?: string
}
