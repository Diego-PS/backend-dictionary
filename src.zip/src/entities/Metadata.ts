export type Metadata = {
  cache: 'HIT' | 'MISS'
  responseTime: number // duration in milisseconds
}
