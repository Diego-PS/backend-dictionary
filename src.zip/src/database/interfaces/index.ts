export * from './IUser'
export * from './IWord'
