export interface IWord {
  word: string
  added: Date
}
