// Imports e configuração inicial
import { AddWordToFavorites } from './AddWordToFavorites';
import { removeWordFromFavorites } from './RemoveWordFromFavorites';
import { AuthController,EntriesController } from 'controllers';
import { UserRepositoryInterface, WordRepositoryInterface } from 'interfaces';
import { Signin, Signup } from 'use-cases';
import { CacheInterface } from 'interfaces';
import { Request, Response } from 'express';

// Mock de dependências
const userRepositoryMock = {
  checkIfWordIsInFavorites: jest.fn(),
  addWordToFavorites: jest.fn(),
  removeWordFromFavorites: jest.fn(),
};

const wordRepositoryMock = {}; // Não usado nos métodos atuais
const cacheMock = { execute: jest.fn() };
const signupUseCaseMock = { execute: jest.fn() };
const signinUseCaseMock = { execute: jest.fn() };

// Mock de Request e Response
const mockRequest = (body: any, params: any = {}, query: any = {}) => ({
  body,
  params,
  query,
});
const mockResponse = () => {
  const res: Partial<Response> = {};
  res.status = jest.fn().mockReturnValue(res);
  res.send = jest.fn().mockReturnValue(res);
  res.set = jest.fn().mockReturnValue(res);
  return res;
};

// Testes para AddWordToFavorites
describe('AddWordToFavorites', () => {
  const addWordToFavorites = new AddWordToFavorites(
    userRepositoryMock as unknown as UserRepositoryInterface,
    wordRepositoryMock as WordRepositoryInterface
  );

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('deve adicionar uma palavra aos favoritos com sucesso', async () => {
    userRepositoryMock.checkIfWordIsInFavorites.mockResolvedValue(false);
    userRepositoryMock.addWordToFavorites.mockResolvedValue({ word: 'teste' });

    const result = await addWordToFavorites.execute('user1', 'teste');
    expect(result).toEqual({ word: 'teste' });
    expect(userRepositoryMock.checkIfWordIsInFavorites).toHaveBeenCalledWith(
      'user1',
      'teste'
    );
    expect(userRepositoryMock.addWordToFavorites).toHaveBeenCalledWith(
      'user1',
      'teste'
    );
  });

  it('deve lançar erro ao adicionar palavra já existente nos favoritos', async () => {
    userRepositoryMock.checkIfWordIsInFavorites.mockResolvedValue(true);

    await expect(addWordToFavorites.execute('user1', 'teste')).rejects.toThrow(
      'word teste is already in favorites'
    );
  });
});

// Testes para removeWordFromFavorites
describe('removeWordFromFavorites', () => {
  const removeWord = new removeWordFromFavorites(
    userRepositoryMock as unknown as UserRepositoryInterface,
    wordRepositoryMock as WordRepositoryInterface
  );

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('deve remover uma palavra dos favoritos com sucesso', async () => {
    userRepositoryMock.checkIfWordIsInFavorites.mockResolvedValue(true);
    userRepositoryMock.removeWordFromFavorites.mockResolvedValue({ word: 'teste' });

    const result = await removeWord.execute('user1', 'teste');
    expect(result).toEqual({ word: 'teste' });
    expect(userRepositoryMock.checkIfWordIsInFavorites).toHaveBeenCalledWith(
      'user1',
      'teste'
    );
    expect(userRepositoryMock.removeWordFromFavorites).toHaveBeenCalledWith(
      'user1',
      'teste'
    );
  });

  it('deve lançar erro ao tentar remover palavra inexistente', async () => {
    userRepositoryMock.checkIfWordIsInFavorites.mockResolvedValue(false);

    await expect(removeWord.execute('user1', 'teste')).rejects.toThrow(
      'The word teste is not in favorites'
    );
  });
});

// Testes para AuthController
describe('AuthController', () => {
  const authController = new AuthController(signupUseCaseMock, signinUseCaseMock);

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('deve realizar signup com sucesso', async () => {
    signupUseCaseMock.execute.mockResolvedValue({ id: '1', name: 'John', token: 'abc' });

    const req = mockRequest({ name: 'John', email: 'john@example.com', password: '1234' });
    const res = mockResponse();

    await authController.signup(req as any, res as Response);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.send).toHaveBeenCalledWith({ id: '1', name: 'John', token: 'abc' });
  });

  it('deve lançar erro no signup com email duplicado', async () => {
    signupUseCaseMock.execute.mockRejectedValue(new Error('Email already exists'));

    const req = mockRequest({ name: 'John', email: 'duplicate@example.com', password: '1234' });
    const res = mockResponse();

    await expect(authController.signup(req as any, res as Response)).rejects.toThrow(
      'Email already exists'
    );
  });
});

// Testes para EntriesController
describe('EntriesController', () => {
  const getEntriesUseCaseMock = { execute: jest.fn() };
  const viewEntryUseCaseMock = { execute: jest.fn() };

  const entriesController = new EntriesController(
    getEntriesUseCaseMock,
    viewEntryUseCaseMock,
    new AddWordToFavorites(userRepositoryMock as any, wordRepositoryMock as any),
    new removeWordFromFavorites(userRepositoryMock as any, wordRepositoryMock as any),
    cacheMock
  );

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('deve obter entradas com sucesso', async () => {
    cacheMock.execute.mockResolvedValue({
      value: { entries: [] },
      metadata: { cache: 'HIT', responseTime: '10ms' },
    });

    const req = mockRequest({}, {}, { search: 'word', page: '1', limit: '10' });
    const res = mockResponse();

    await entriesController.getEntries(req as any, res as Response);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.send).toHaveBeenCalledWith({ entries: [] });
  });
});
